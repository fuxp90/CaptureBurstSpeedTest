java -jar UdpServer.main.jar

